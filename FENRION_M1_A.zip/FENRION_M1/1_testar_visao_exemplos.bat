@echo off
title FENRION M1 - teste da visao
cd /d "%~dp0"
set PY=.venv\Scripts\python.exe
if not exist %PY% (
  echo Ambiente nao instalado. Rode primeiro o 0_instalar.bat
  pause
  exit /b 1
)
echo Abrindo as imagens de exemplo. Feche cada janela com qualquer tecla.
for %%F in (exemplos\*.png) do (
  echo.
  echo === %%F
  %PY% m1_visao.py --img "%%F"
)
echo.
pause
