@echo off
title FENRION M1 - simulador
cd /d "%~dp0"
set PY=.venv\Scripts\python.exe
if not exist %PY% (
  echo Ambiente nao instalado. Rode primeiro o 0_instalar.bat
  pause
  exit /b 1
)
echo Simulador proprio da Missao 1 (nao precisa de drone).
set ARENA=
set /p ARENA=Numero da arena (Enter = sorteio):
if "%ARENA%"=="" (
  %PY% m1_missao.py --sim
) else (
  %PY% m1_missao.py --sim --seed %ARENA%
)
echo.
pause
