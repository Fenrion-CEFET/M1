@echo off
title FENRION M1 - camera em bancada
cd /d "%~dp0"
set PY=.venv\Scripts\python.exe
if not exist %PY% (
  echo Ambiente nao instalado. Rode primeiro o 0_instalar.bat
  pause
  exit /b 1
)
echo Visao com a camera real (ESP32-S3) ou a webcam do notebook.
%PY% m1_visao.py
echo.
pause
