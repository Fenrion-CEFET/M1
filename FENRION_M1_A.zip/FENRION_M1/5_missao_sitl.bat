@echo off
title FENRION M1 - SITL
cd /d "%~dp0"
set PY=.venv\Scripts\python.exe
if not exist %PY% (
  echo Ambiente nao instalado. Rode primeiro o 0_instalar.bat
  pause
  exit /b 1
)
echo Missao no SITL do Mission Planner (aba SIMULATION, Multirotor ja rodando).
set PORTA=5762
set /p PORTA=Porta TCP do SITL (Enter = 5762):
%PY% m1_missao.py --sitl --conn tcp:127.0.0.1:%PORTA%
echo.
pause
