@echo off
title FENRION M1 - DRONE REAL
cd /d "%~dp0"
set PY=.venv\Scripts\python.exe
if not exist %PY% (
  echo Ambiente nao instalado. Rode primeiro o 0_instalar.bat
  pause
  exit /b 1
)
REM Origem aproximada (Nepomuceno-MG), usada so em voo sem GPS
set ORIGEM_LAT=-21.235
set ORIGEM_LON=-45.235

echo ************************************************************
echo  ATENCAO: MODO REAL. O drone vai decolar sozinho.
echo  Feche o Mission Planner antes (ele ocupa a porta 14550).
echo  Piloto de seguranca com o radio na mao. Veja o README.
echo ************************************************************
echo.
set CAMIP=
set /p CAMIP=IP da camera ESP32-S3:
if "%CAMIP%"=="" goto fim
set INDOOR=s
set /p INDOOR=Voo sem GPS, usando o MTF-01? (s/n, Enter = s):
if /i "%INDOOR%"=="s" (
  %PY% m1_missao.py --real --cam-ip %CAMIP% --origem %ORIGEM_LAT% %ORIGEM_LON% --rangefinder
) else (
  %PY% m1_missao.py --real --cam-ip %CAMIP%
)
:fim
echo.
pause
