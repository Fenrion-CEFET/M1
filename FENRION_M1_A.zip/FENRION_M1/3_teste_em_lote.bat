@echo off
title FENRION M1 - teste em lote
cd /d "%~dp0"
set PY=.venv\Scripts\python.exe
if not exist %PY% (
  echo Ambiente nao instalado. Rode primeiro o 0_instalar.bat
  pause
  exit /b 1
)
set INI=1
set FIM=10
set /p INI=Primeira arena (Enter = 1):
set /p FIM=Ultima arena (Enter = 10):
%PY% teste_lote.py %INI% %FIM%
echo.
pause
