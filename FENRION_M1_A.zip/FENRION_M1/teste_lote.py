"""
Teste em lote da Missao 1 no simulador proprio.

Roda a missao em varias arenas sorteadas (sem janela) e mostra quantas
terminaram pousando na base correta. Use SEMPRE antes e depois de mudar o codigo,
para ter certeza de que a mudanca melhorou (e nao piorou) o resultado.

  python teste_lote.py            -> arenas 1 a 10
  python teste_lote.py 1 30       -> arenas 1 a 30
"""
import re
import subprocess
import sys
import time

TOL_CM = 15  # pouso considerado certo ate esta distancia do centro da base correta

ini = int(sys.argv[1]) if len(sys.argv) > 1 else 1
fim = int(sys.argv[2]) if len(sys.argv) > 2 else 10
ok, tempos = 0, []
t0 = time.time()
print(f"Teste em lote: arenas {ini} a {fim} (pode levar alguns minutos)\n")
for seed in range(ini, fim + 1):
    r = subprocess.run([sys.executable, "m1_missao.py", "--sim", "--seed", str(seed),
                        "--sem-janela", "--tmax", "150"], capture_output=True, text=True)
    out = r.stdout + r.stderr
    esp = re.search(r"resposta esperada: (\('\w+', \d\))", out)
    esc = re.search(r"Base escolhida: (\w+) (\d)", out)
    dist = re.search(r"centro dela: (\d+) cm", out)
    tf = re.search(r"FIM em ([\d.]+) s", out)
    esp = esp.group(1) if esp else "?"
    esc = f"('{esc.group(1)}', {esc.group(2)})" if esc else "nenhuma"
    d = int(dist.group(1)) if dist else None
    t = float(tf.group(1)) if tf else None
    certo = esp == esc and d is not None and d <= TOL_CM
    ok += certo
    if certo and t:
        tempos.append(t)
    print(f"arena {seed:3d}: {'OK   ' if certo else 'FALHA'} esperado {esp:16s} escolhido {esc:16s} "
          f"distancia {d if d is not None else '-':>4} cm  tempo {t if t else '-'} s")
    if r.returncode != 0 and not tf:
        print("   erro ao rodar:", out.strip().splitlines()[-1] if out.strip() else "sem saida")

n = fim - ini + 1
print(f"\nRESULTADO: {ok}/{n} pousos corretos ({100 * ok / n:.0f}%)")
if tempos:
    print(f"Tempo medio da missao (acertos): {sum(tempos) / len(tempos):.1f} s")
print(f"Duracao do teste: {time.time() - t0:.0f} s")
