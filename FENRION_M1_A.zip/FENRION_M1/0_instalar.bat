@echo off
title FENRION M1 - instalacao
cd /d "%~dp0"
echo ============================================================
echo  FENRION M1 - instalacao do ambiente (rodar uma vez so)
echo ============================================================
echo.
set BASEPY=
py -3 --version >nul 2>nul && set BASEPY=py -3
if not defined BASEPY (
  python --version >nul 2>nul && set BASEPY=python
)
if not defined BASEPY goto sempython
echo Python encontrado:
%BASEPY% --version
echo.
echo [1/3] Criando o ambiente virtual na pasta .venv ...
%BASEPY% -m venv .venv
if errorlevel 1 goto erro
echo.
echo [2/3] Instalando as bibliotecas (precisa de internet, 2 a 5 minutos) ...
.venv\Scripts\python.exe -m pip install --upgrade pip
.venv\Scripts\python.exe -m pip install -r requirements.txt
if errorlevel 1 goto erro
echo.
echo [3/3] Conferindo ...
.venv\Scripts\python.exe -c "import cv2, numpy, pymavlink, requests; cv2.aruco.ArucoDetector; print('OpenCV', cv2.__version__, '- tudo OK')"
if errorlevel 1 goto erro
echo.
echo ============================================================
echo  INSTALACAO CONCLUIDA. Proximo passo: 1_testar_visao_exemplos.bat
echo ============================================================
pause
exit /b 0

:sempython
echo ERRO: Python nao encontrado.
echo Instale o Python 3.12 (python.org) marcando "Add python.exe to PATH"
echo e rode este arquivo de novo. Veja o passo 1 do README.
pause
exit /b 1

:erro
echo.
echo ERRO na instalacao. Copie as mensagens acima e envie para a equipe.
pause
exit /b 1
