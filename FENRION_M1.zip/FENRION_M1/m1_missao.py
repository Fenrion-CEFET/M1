"""
FENRION - Missao 1 "Bouncing 2.0" - programa da missao autonoma

Fluxo: decolar -> buscar (varredura) -> mapear gabarito e bases -> decidir
       -> ir ate a base correta -> alinhar pela camera descendo -> pousar -> desarmar

Modos:
  python m1_missao.py --sim                      simulador proprio (sem drone, sem SITL)
  python m1_missao.py --sitl                     SITL do Mission Planner (aba SIMULATION)
  python m1_missao.py --real --cam-ip 192.168.0.50   drone real (MAVLink pela ESP8266)

No simulador e no SITL a camera e virtual: uma arena desenhada e "fotografada"
conforme a posicao do drone, e a imagem passa pelo MESMO codigo de visao do drone real.

Teclas na janela: q = abortar (pousa onde esta), espaco = pausar (so no --sim)
"""

import argparse
import csv
import math
import random
import threading
import time

import cv2
import numpy as np

import m1_visao as vis

vis.MAX_AREA_FRAC = 0.6  # perto do chao a base ocupa boa parte da imagem

# ===================== Parametros da missao =====================
ALT_BUSCA = 3.0          # m, altura da varredura (camera ve ~3,5 x 2,6 m)
ALT_FINAL = 1.0          # m, abaixo disso e alinhado: comando LAND (a base passa a ocupar a imagem toda)
V_MAX = 0.6              # m/s, velocidade maxima no alinhamento
KP_ALINHA = 0.8          # ganho proporcional (m/s por metro de erro)
KI_ALINHA = 0.25         # ganho integral (corrige vento constante)
V_DESCIDA = 0.35         # m/s, descida durante o alinhamento
TOL_ALINHA = 0.12        # m, erro horizontal para permitir descer (cresce com a altura)
VOTOS_MIN = 3            # deteccoes iguais para confiar em uma base/gabarito
# varredura em (leste, norte) metros, relativo ao ponto de decolagem
VARREDURA = [(0, 0), (-1.8, 1.0), (-1.8, -1.0), (0, -1.2), (1.8, -1.0), (1.8, 1.0), (0, 1.2)]

# ===================== Camera =====================
CAM_HFOV_DEG = 60.0      # campo de visao horizontal da OV5640 (medir e ajustar!)
CAM_YAW_OFFSET = 0.0     # graus; 0 = topo da imagem aponta para a frente do drone
CAM_W, CAM_H = 640, 480  # resolucao usada no simulador

DIVS = (3, 4, 5)


# ===================== Geometria =====================
def px_to_body(px, size, alt):
    """Pixel -> deslocamento no solo (frente, direita) em metros, camera para baixo."""
    W, H = size
    mpp = 2 * max(alt, 0.2) * math.tan(math.radians(CAM_HFOV_DEG) / 2) / W
    right = (px[0] - W / 2) * mpp
    fwd = -(px[1] - H / 2) * mpp
    if CAM_YAW_OFFSET:
        a = math.radians(CAM_YAW_OFFSET)
        fwd, right = fwd * math.cos(a) - right * math.sin(a), fwd * math.sin(a) + right * math.cos(a)
    return fwd, right


def body_to_ne(fwd, right, yaw):
    return (fwd * math.cos(yaw) - right * math.sin(yaw),
            fwd * math.sin(yaw) + right * math.cos(yaw))


def ne_to_body(n, e, yaw):
    return (n * math.cos(yaw) + e * math.sin(yaw),
            -n * math.sin(yaw) + e * math.cos(yaw))


# ===================== Arena virtual (sim e SITL) =====================
class ArenaVirtual:
    PX_M = 200  # pixels por metro no desenho
    SLOTS = [(-0.6, 1.4), (1.8, 1.3), (2.2, 0.0), (-1.8, -1.2), (-0.4, -1.5), (1.6, -1.4)]  # (leste, norte)
    GAB_POS = (-2.0, 0.8)

    def __init__(self, seed=None, aruco_id=None, gab_kind=None):
        rnd = random.Random(seed)
        kinds = ["hexagono", "triangulo", "estrela"]
        bases = []
        for k in kinds:  # como na figura: cada forma aparece com 2 dos 3 numeros
            for d in rnd.sample(DIVS, 2):
                bases.append((k, d))
        rnd.shuffle(bases)
        self.bases = [(k, d, p) for (k, d), p in zip(bases, self.SLOTS)]
        self.gab_kind = gab_kind or rnd.choice(kinds)
        present = [d for k, d, _ in self.bases if k == self.gab_kind]
        if aruco_id is None:
            ok = [i for i in range(1, 50) if len([d for d in present if i % d == 0]) == 1]
            aruco_id = rnd.choice(ok)
        self.aruco_id = aruco_id
        corretas = [(k, d) for k, d, _ in self.bases if k == self.gab_kind and aruco_id % d == 0]
        self.correta = corretas[0] if len(corretas) == 1 else None
        self.img = self._draw()

    def _xy(self, e, n):
        H, W = self.img_shape
        return int(W / 2 + e * self.PX_M), int(H / 2 - n * self.PX_M)

    def _poly(self, kind, c, r):
        cx, cy = c
        if kind == "estrela":
            pts = [(cx + (r if i % 2 == 0 else r * 0.45) * math.cos(math.radians(i * 36 - 90)),
                    cy + (r if i % 2 == 0 else r * 0.45) * math.sin(math.radians(i * 36 - 90))) for i in range(10)]
        else:
            n = 6 if kind == "hexagono" else 3
            off = 0 if n == 6 else -90
            pts = [(cx + r * math.cos(math.radians(i * 360 / n + off)),
                    cy + r * math.sin(math.radians(i * 360 / n + off))) for i in range(n)]
        return np.array(pts, np.int32)

    def _draw(self):
        W, H = int(7 * self.PX_M), int(5 * self.PX_M)
        self.img_shape = (H, W)
        img = np.full((H, W, 3), 165, np.uint8)
        R = int(0.33 * self.PX_M)
        cv2.circle(img, self._xy(0, 0), int(0.45 * self.PX_M), (230, 60, 20), -1)  # base de decolagem azul
        for k, d, (e, n) in self.bases:
            c = self._xy(e, n)
            cv2.circle(img, c, int(0.45 * self.PX_M), (255, 255, 255), -1)
            cv2.polylines(img, [self._poly(k, c, R)], True, (0, 0, 0), 6, cv2.LINE_AA)
            (tw, th), _ = cv2.getTextSize(str(d), cv2.FONT_HERSHEY_SIMPLEX, 2.6, 8)
            cv2.putText(img, str(d), (c[0] - tw // 2, c[1] + th // 2), cv2.FONT_HERSHEY_SIMPLEX, 2.6, (0, 0, 0), 8, cv2.LINE_AA)
        c = self._xy(*self.GAB_POS)
        Rg = {"hexagono": 0.42, "triangulo": 0.55, "estrela": 0.6}[self.gab_kind]
        cv2.circle(img, c, int((Rg + 0.08) * self.PX_M), (255, 255, 255), -1)
        cv2.polylines(img, [self._poly(self.gab_kind, c, int(Rg * self.PX_M))], True, (0, 0, 0), 6, cv2.LINE_AA)
        ms = int(0.22 * self.PX_M)
        mk = cv2.aruco.generateImageMarker(cv2.aruco.getPredefinedDictionary(cv2.aruco.DICT_4X4_50), self.aruco_id, ms)
        mk = cv2.copyMakeBorder(mk, 6, 6, 6, 6, cv2.BORDER_CONSTANT, value=255)
        s = mk.shape[0]
        cy0 = c[1] - s // 2 + (int(0.08 * self.PX_M) if self.gab_kind == "triangulo" else 0)
        img[cy0:cy0 + s, c[0] - s // 2:c[0] - s // 2 + s] = cv2.cvtColor(mk, cv2.COLOR_GRAY2BGR)
        return img

    def photo(self, n, e, alt, yaw):
        """Imagem da camera virtual apontada para baixo."""
        H, W = self.img_shape
        mpp = 2 * max(alt, 0.15) * math.tan(math.radians(CAM_HFOV_DEG) / 2) / CAM_W
        k = self.PX_M * mpp
        c, s = math.cos(yaw), math.sin(yaw)
        cx, cy = W / 2 + e * self.PX_M, H / 2 - n * self.PX_M
        M = np.array([[k * c, -k * s, cx - k * c * CAM_W / 2 + k * s * CAM_H / 2],
                      [k * s, k * c, cy - k * s * CAM_W / 2 - k * c * CAM_H / 2]], np.float32)
        img = cv2.warpAffine(self.img, M, (CAM_W, CAM_H), flags=cv2.WARP_INVERSE_MAP | cv2.INTER_AREA,
                             borderValue=(120, 120, 120))
        img = cv2.GaussianBlur(img, (3, 3), 0)
        noise = np.random.normal(0, 4, img.shape)
        return np.clip(img + noise, 0, 255).astype(np.uint8)


# ===================== Drone simulado (cinematico) =====================
class SimDrone:
    """Modelo simples: acompanha a velocidade comandada com atraso de 1a ordem, com vento leve."""
    def __init__(self):
        self.n = self.e = 0.0
        self.alt = 0.0
        self.yaw = math.radians(random.uniform(-30, 30))
        self.v = np.zeros(3)  # norte, leste, subida
        self.cmd = ("idle",)
        self.armed = False
        self.t = 0.0
        self.wind = np.array([random.uniform(-0.1, 0.1), random.uniform(-0.1, 0.1), 0])

    def update(self, dt=0.1):
        self.t += dt
        if self.cmd[0] == "pos":
            _, tn, te, ta = self.cmd
            d = np.array([tn - self.n, te - self.e, ta - self.alt])
            vd = d * 1.0
            sp = np.linalg.norm(vd[:2])
            if sp > 1.0:
                vd[:2] *= 1.0 / sp
            vd[2] = np.clip(vd[2], -0.8, 1.0)
        elif self.cmd[0] == "vel":
            _, fwd, right, down = self.cmd
            vn, ve = body_to_ne(fwd, right, self.yaw)
            vd = np.array([vn, ve, -down])
        elif self.cmd[0] == "land":
            vd = np.array([0, 0, -0.5 if self.alt > 0.5 else -0.3])
        else:
            vd = np.zeros(3)
        if self.alt <= 0.01 and self.cmd[0] in ("idle", "land"):
            self.v[:] = 0
            self.alt = 0
            return
        self.v += (vd - self.v) * min(1, dt / 0.35)
        # vento so atrapalha no comando de velocidade (em posicao/LAND a controladora compensa)
        w = self.wind if (self.alt > 0.05 and self.cmd[0] == "vel") else np.zeros(3)
        self.n += (self.v[0] + w[0]) * dt
        self.e += (self.v[1] + w[1]) * dt
        self.alt = max(0.0, self.alt + self.v[2] * dt)

    # interface comum
    def arm_takeoff(self, alt):
        self.armed = True
        self.cmd = ("pos", self.n, self.e, alt)

    def goto(self, n, e, alt):
        self.cmd = ("pos", n, e, alt)

    def vel_body(self, fwd, right, down):
        self.cmd = ("vel", fwd, right, down)

    def land(self):
        self.cmd = ("land",)

    def landed(self):
        return self.alt <= 0.02 and self.cmd[0] == "land"

    def disarm(self):
        self.armed = False
        self.cmd = ("idle",)

    def pose(self):
        return self.n, self.e, self.alt, self.yaw


# ===================== Drone real / SITL via MAVLink =====================
class MavDrone:
    def __init__(self, conn, origem=None, usar_rangefinder=False):
        from pymavlink import mavutil
        self.mu = mavutil
        print("Conectando em", conn, "...")
        self.m = mavutil.mavlink_connection(conn, source_system=255)
        self.m.wait_heartbeat(timeout=30)
        print(f"Heartbeat do sistema {self.m.target_system}")
        self.ts, self.tc = self.m.target_system, self.m.target_component
        self.L = mavutil.mavlink
        self.local = None
        self.yaw = 0.0
        self.armed = False
        self.landed_state = 0
        self.rng = None
        self.rng_t = 0
        self.usar_rng = usar_rangefinder
        self.start = None
        self._set_rates()
        if origem:
            lat, lon = origem
            self.m.mav.set_gps_global_origin_send(self.ts, int(lat * 1e7), int(lon * 1e7), 0)
            self._cmd(self.L.MAV_CMD_DO_SET_HOME, 0, 0, 0, 0, lat, lon, 0)
            print("Origem do EKF definida (voo sem GPS)")
        t0 = time.time()
        while self.local is None and time.time() - t0 < 15:
            self.update()
            time.sleep(0.05)
        if self.local is None:
            raise SystemExit("Sem LOCAL_POSITION_NED: o EKF ainda nao tem posicao (fluxo optico/GPS/origem?)")

    def _cmd(self, cmd, *p):
        p = list(p) + [0] * (7 - len(p))
        self.m.mav.command_long_send(self.ts, self.tc, cmd, 0, *p)

    def _set_rates(self):
        for msg_id, hz in ((32, 20), (30, 20), (245, 2), (132, 10), (0, 1)):
            self._cmd(self.L.MAV_CMD_SET_MESSAGE_INTERVAL, msg_id, int(1e6 / hz))
        self.m.mav.request_data_stream_send(self.ts, self.tc, self.L.MAV_DATA_STREAM_ALL, 10, 1)

    def update(self, dt=None):
        while True:
            msg = self.m.recv_match(blocking=False)
            if msg is None:
                break
            t = msg.get_type()
            if t == "LOCAL_POSITION_NED":
                self.local = (msg.x, msg.y, msg.z)
            elif t == "ATTITUDE":
                self.yaw = msg.yaw
            elif t == "HEARTBEAT" and msg.get_srcSystem() == self.ts and msg.type != self.L.MAV_TYPE_GCS:
                self.armed = bool(msg.base_mode & self.L.MAV_MODE_FLAG_SAFETY_ARMED)
            elif t == "EXTENDED_SYS_STATE":
                self.landed_state = msg.landed_state
            elif t == "DISTANCE_SENSOR":
                self.rng = msg.current_distance / 100.0
                self.rng_t = time.time()
            elif t == "STATUSTEXT":
                print("[Pixhawk]", msg.text)

    def set_mode(self, name):
        mid = self.m.mode_mapping()[name]
        self.m.mav.set_mode_send(self.ts, self.L.MAV_MODE_FLAG_CUSTOM_MODE_ENABLED, mid)

    def arm_takeoff(self, alt):
        self.start = self.local
        self.set_mode("GUIDED")
        time.sleep(1)
        self._cmd(self.L.MAV_CMD_COMPONENT_ARM_DISARM, 1)
        t0 = time.time()
        while not self.armed and time.time() - t0 < 10:
            self.update()
            time.sleep(0.1)
        if not self.armed:
            raise SystemExit("Nao armou: veja as mensagens [Pixhawk] acima (pre-arm checks)")
        time.sleep(1)
        self._cmd(self.L.MAV_CMD_NAV_TAKEOFF, 0, 0, 0, 0, 0, 0, alt)

    def pose(self):
        x, y, z = self.local
        sx, sy, sz = self.start if self.start else self.local
        alt = sz - z
        if self.usar_rng and self.rng is not None and time.time() - self.rng_t < 0.5:
            alt = self.rng
        return x - sx, y - sy, alt, self.yaw

    def goto(self, n, e, alt):
        sx, sy, sz = self.start
        self.m.mav.set_position_target_local_ned_send(
            0, self.ts, self.tc, self.L.MAV_FRAME_LOCAL_NED, 0b110111111000,
            sx + n, sy + e, sz - alt, 0, 0, 0, 0, 0, 0, 0, 0)

    def vel_body(self, fwd, right, down):
        self.m.mav.set_position_target_local_ned_send(
            0, self.ts, self.tc, self.L.MAV_FRAME_BODY_OFFSET_NED, 0b110111000111,
            0, 0, 0, fwd, right, down, 0, 0, 0, 0, 0)

    def land(self):
        self.set_mode("LAND")

    def landed(self):
        return self.landed_state == self.L.MAV_LANDED_STATE_ON_GROUND or not self.armed

    def disarm(self):
        self._cmd(self.L.MAV_CMD_COMPONENT_ARM_DISARM, 0)
        time.sleep(0.5)
        self.update()
        if self.armed:  # pousado mas ainda armado: forca o desarme (desliga os rotores)
            self._cmd(self.L.MAV_CMD_COMPONENT_ARM_DISARM, 0, 21196)


# ===================== Camera real (stream com thread) =====================
class StreamCam:
    """Le o stream em segundo plano e entrega sempre o quadro mais novo (evita atraso acumulado)."""
    def __init__(self, url):
        self.cap = cv2.VideoCapture(url)
        if not self.cap.isOpened():
            raise SystemExit("Nao consegui abrir o stream " + url)
        self.frame = None
        self.lock = threading.Lock()
        threading.Thread(target=self._run, daemon=True).start()
        t0 = time.time()
        while self.frame is None and time.time() - t0 < 10:
            time.sleep(0.05)

    def _run(self):
        while True:
            ok, f = self.cap.read()
            if ok:
                with self.lock:
                    self.frame = f

    def read(self):
        with self.lock:
            return None if self.frame is None else self.frame.copy()


# ===================== Mapa e decisao =====================
class Mapa:
    def __init__(self):
        self.bases = []      # {kind, digit, n, e, votos}
        self.gab_votos = {}  # (id, kind) -> votos
        self.gab_pos = None

    def add(self, st, pose):
        n0, e0, alt, yaw = pose
        if alt < 1.0:  # perto do chao a imagem fica parcial: nao alimenta o mapa
            return
        if st["aruco_id"] is not None and st["gab_kind"]:
            key = (st["aruco_id"], st["gab_kind"])
            self.gab_votos[key] = self.gab_votos.get(key, 0) + 1
            f, r = px_to_body(st["gab_px"], st["size"], alt)
            dn, de = body_to_ne(f, r, yaw)
            self.gab_pos = (n0 + dn, e0 + de)
        for b in st["bases"]:
            f, r = px_to_body(b["px"], st["size"], alt)
            dn, de = body_to_ne(f, r, yaw)
            n, e = n0 + dn, e0 + de
            for m in self.bases:
                if m["kind"] == b["kind"] and m["digit"] == b["digit"] and math.hypot(m["n"] - n, m["e"] - e) < 0.6:
                    k = m["votos"]
                    m["n"], m["e"] = (m["n"] * k + n) / (k + 1), (m["e"] * k + e) / (k + 1)
                    m["votos"] = k + 1
                    break
            else:
                self.bases.append({"kind": b["kind"], "digit": b["digit"], "n": n, "e": e, "votos": 1})

    def gabarito(self):
        if not self.gab_votos:
            return None
        (mid, kind), v = max(self.gab_votos.items(), key=lambda kv: kv[1])
        return (mid, kind) if v >= VOTOS_MIN else None

    def decidir(self):
        g = self.gabarito()
        if g is None:
            return None, "procurando gabarito"
        mid, kind = g
        divs = [d for d in DIVS if mid % d == 0]
        cands = [b for b in self.bases if b["kind"] == kind and b["digit"] in divs and b["votos"] >= VOTOS_MIN]
        if not cands:
            return None, f"ID {mid} ({kind}), divisores {divs}: procurando a base"
        alvo = max(cands, key=lambda b: b["votos"])
        aviso = " (ID AMBIGUO)" if len({b['digit'] for b in cands}) > 1 else ""
        return alvo, f"ID {mid} ({kind}) -> {alvo['kind']} {alvo['digit']}{aviso}"


# ===================== Maquina de estados da missao =====================
class Missao:
    def __init__(self, drone, log):
        self.d = drone
        self.mapa = Mapa()
        self.estado = "DECOLAR"
        self.t_estado = 0.0
        self.wp = 0
        self.voltas = 0
        self.alvo = None
        self.info = ""
        self.t_visto = 0.0
        self.log = log
        self.fim_msg = ""

    def muda(self, novo, agora):
        print(f"[{agora:6.1f}s] {self.estado} -> {novo}  {self.info}")
        self.estado, self.t_estado = novo, agora

    def abortar(self, agora):
        if self.estado not in ("POUSO", "FIM"):
            self.info = "ABORTADO pelo operador"
            self.d.land()
            self.muda("POUSO", agora)

    def passo(self, st, agora):
        n, e, alt, yaw = self.d.pose()
        dt_est = agora - self.t_estado
        if st is not None and self.estado in ("BUSCA", "IR_ALVO"):
            self.mapa.add(st, (n, e, alt, yaw))

        if self.estado == "DECOLAR":
            if dt_est == 0 or not getattr(self, "_decolou", False):
                self.d.arm_takeoff(ALT_BUSCA)
                self._decolou = True
            if alt > 0.9 * ALT_BUSCA:
                self.muda("BUSCA", agora)
            elif dt_est > 25:
                self.info = "nao atingiu a altura de busca"
                self.d.land()
                self.muda("POUSO", agora)

        elif self.estado == "BUSCA":
            alvo, self.info = self.mapa.decidir()
            if alvo is not None:
                self.alvo = alvo
                self.muda("IR_ALVO", agora)
                return
            we, wn = VARREDURA[self.wp]
            self.d.goto(wn, we, ALT_BUSCA)
            if math.hypot(wn - n, we - e) < 0.25:
                if not hasattr(self, "_chegou"):
                    self._chegou = agora
                elif agora - self._chegou > 1.0:  # para um pouco em cada ponto para a imagem estabilizar
                    del self._chegou
                    self.wp += 1
                    if self.wp >= len(VARREDURA):
                        self.wp = 0
                        self.voltas += 1
                        if self.voltas >= 2:
                            self.info = "base nao encontrada em 2 voltas: pousando na origem"
                            self.d.goto(0, 0, ALT_BUSCA)
                            self.muda("VOLTA_ORIGEM", agora)

        elif self.estado == "VOLTA_ORIGEM":
            self.d.goto(0, 0, ALT_BUSCA)
            if math.hypot(n, e) < 0.3:
                self.d.land()
                self.muda("POUSO", agora)

        elif self.estado == "IR_ALVO":
            self.d.goto(self.alvo["n"], self.alvo["e"], ALT_BUSCA)
            if math.hypot(self.alvo["n"] - n, self.alvo["e"] - e) < 0.3:
                self.t_visto = agora
                self.muda("ALINHAR", agora)

        elif self.estado == "ALINHAR":
            det = None
            if st is not None:
                cands = [b for b in st["bases"] if b["kind"] == self.alvo["kind"] and b["digit"] == self.alvo["digit"]]
                if cands:  # o mais proximo de onde o mapa diz que a base esta
                    def dist(b):
                        f, r = px_to_body(b["px"], st["size"], alt)
                        dn, de = body_to_ne(f, r, yaw)
                        return math.hypot(n + dn - self.alvo["n"], e + de - self.alvo["e"])
                    det = min(cands, key=dist)
                    if dist(det) > 0.8:
                        det = None
            if det is not None:
                self.t_visto = agora
                f, r = px_to_body(det["px"], st["size"], alt)
                dn, de = body_to_ne(f, r, yaw)
                self.alvo["n"], self.alvo["e"] = n + dn, e + de
                err = math.hypot(f, r)
                dti = min(0.3, agora - getattr(self, "_t_ant", agora))
                self._t_ant = agora
                self._if = float(np.clip(getattr(self, "_if", 0.0) + f * dti, -0.8, 0.8))
                self._ir = float(np.clip(getattr(self, "_ir", 0.0) + r * dti, -0.8, 0.8))
                self._err = err
                vf = float(np.clip(KP_ALINHA * f + KI_ALINHA * self._if, -V_MAX, V_MAX))
                vr = float(np.clip(KP_ALINHA * r + KI_ALINHA * self._ir, -V_MAX, V_MAX))
                tol = TOL_ALINHA * max(1.0, alt / 1.5)
                vd = V_DESCIDA if err < tol else 0.0
                self.info = f"alinhando: erro {err * 100:.0f} cm, alt {alt:.2f} m"
                if alt <= ALT_FINAL and err < tol:
                    self.d.land()
                    self.muda("POUSO", agora)
                    return
                self.d.vel_body(vf, vr, vd)
            else:
                perdido = agora - self.t_visto
                self._t_ant = agora
                if alt <= ALT_FINAL + 0.4 and perdido < 1.5 and getattr(self, "_err", 1) < 0.15:
                    # muito baixo, a base ocupa a imagem toda: confia na ultima posicao e pousa
                    self.d.land()
                    self.info = "base saiu da imagem na reta final: pousando"
                    self.muda("POUSO", agora)
                    return
                if perdido > 6:
                    self.info = "base perdida: voltando a altura de busca"
                    self.muda("IR_ALVO", agora)
                else:
                    self.d.vel_body(0, 0, -0.25 if alt < ALT_BUSCA else 0)  # sobe devagar para reencontrar
                    self.info = f"base fora da imagem ha {perdido:.1f} s"

        elif self.estado == "POUSO":
            if self.d.landed():
                self.d.disarm()
                self.muda("FIM", agora)

        self.log.writerow([f"{agora:.2f}", self.estado, f"{n:.2f}", f"{e:.2f}", f"{alt:.2f}",
                           f"{math.degrees(yaw):.0f}", self.info])


# ===================== Programa principal =====================
def main():
    ap = argparse.ArgumentParser(description="FENRION M1 - missao autonoma")
    g = ap.add_mutually_exclusive_group()
    g.add_argument("--sim", action="store_true", help="simulador proprio (padrao)")
    g.add_argument("--sitl", action="store_true", help="SITL do Mission Planner")
    g.add_argument("--real", action="store_true", help="drone real")
    ap.add_argument("--conn", help="conexao MAVLink (padrao: sitl tcp:127.0.0.1:5762, real udpin:0.0.0.0:14550)")
    ap.add_argument("--cam-ip", help="IP da ESP32-S3 (modo real)")
    ap.add_argument("--origem", nargs=2, type=float, metavar=("LAT", "LON"),
                    help="define a origem do EKF (voo indoor sem GPS)")
    ap.add_argument("--rangefinder", action="store_true", help="usar o MTF-01 para a altura")
    ap.add_argument("--seed", type=int, help="sorteio da arena virtual")
    ap.add_argument("--id", type=int, help="ID do ArUco na arena virtual")
    ap.add_argument("--sem-janela", action="store_true", help="nao mostrar janela (testes automaticos)")
    ap.add_argument("--tmax", type=float, default=240, help="tempo maximo da missao (s)")
    args = ap.parse_args()
    if not (args.sitl or args.real):
        args.sim = True

    arena = None
    if args.sim or args.sitl:
        arena = ArenaVirtual(seed=args.seed, aruco_id=args.id)
        print(f"Arena virtual: gabarito {arena.gab_kind} com ID {arena.aruco_id}; "
              f"resposta esperada: {arena.correta}")

    if args.sim:
        drone = SimDrone()
    else:
        if args.real:
            if not args.cam_ip:
                raise SystemExit("Informe --cam-ip no modo real")
            print("\n*** MODO REAL: o drone vai decolar sozinho. ***")
            print("Piloto de seguranca com o radio na mao, area livre, helices conferidas.")
            if input("Digite VOAR para continuar: ").strip() != "VOAR":
                raise SystemExit("Cancelado.")
        conn = args.conn or ("tcp:127.0.0.1:5762" if args.sitl else "udpin:0.0.0.0:14550")
        drone = MavDrone(conn, origem=args.origem, usar_rangefinder=args.rangefinder)

    cam = StreamCam(f"http://{args.cam_ip}:81/stream") if args.real else None
    finder = vis.ArucoFinder(vis.ARUCO_DICTS)
    templates = vis.make_templates()

    import os
    pasta_log = os.path.join(os.path.dirname(os.path.abspath(__file__)), "logs")
    os.makedirs(pasta_log, exist_ok=True)
    nome_log = os.path.join(pasta_log, time.strftime("m1_log_%Y%m%d_%H%M%S.csv"))
    with open(nome_log, "w", newline="", encoding="utf-8") as flog:
        log = csv.writer(flog, delimiter=";")
        log.writerow(["t", "estado", "norte", "leste", "alt", "yaw", "info"])
        miss = Missao(drone, log)
        t0 = time.time()
        pausado = False
        while miss.estado != "FIM":
            if args.sim:
                if not pausado:
                    drone.update(0.1)
                agora = drone.t
            else:
                drone.update()
                agora = time.time() - t0
            if agora > args.tmax:
                miss.info = "tempo maximo atingido"
                miss.abortar(agora)

            n, e, alt, yaw = drone.pose()
            if arena is not None:
                frame = arena.photo(n, e, alt, yaw)
            else:
                frame = cam.read()
            st, view = None, None
            if frame is not None:
                view, _, _, st = vis.process(frame, finder, templates)
            if not pausado:
                miss.passo(st, agora)

            if not args.sem_janela and view is not None:
                hud = f"{miss.estado} | N {n:+.2f} L {e:+.2f} alt {alt:.2f} | {miss.info}"
                cv2.rectangle(view, (0, view.shape[0] - 24), (view.shape[1], view.shape[0]), (0, 0, 0), -1)
                cv2.putText(view, hud[:95], (6, view.shape[0] - 7), cv2.FONT_HERSHEY_SIMPLEX, 0.45, (0, 255, 255), 1)
                cv2.imshow("M1 missao", view)
                k = cv2.waitKey(1 if args.sim else 1) & 0xFF
                if k == ord("q"):
                    miss.abortar(agora)
                elif k == ord(" ") and args.sim:
                    pausado = not pausado
            if not args.sim:
                time.sleep(0.03)

    n, e, alt, _ = drone.pose()
    print(f"\nFIM em {agora:.1f} s. Posicao final: norte {n:+.2f} m, leste {e:+.2f} m")
    if miss.alvo:
        erro = math.hypot(n - miss.alvo["n"], e - miss.alvo["e"])
        print(f"Base escolhida: {miss.alvo['kind']} {miss.alvo['digit']} (erro de pouso estimado {erro * 100:.0f} cm)")
    if arena is not None:
        real = [p for k, d, p in arena.bases if (k, d) == arena.correta]
        if real:
            ee, nn = real[0]
            print(f"Resposta esperada: {arena.correta}; distancia ate o centro dela: "
                  f"{math.hypot(n - nn, e - ee) * 100:.0f} cm")
    print("Log salvo em", nome_log)
    if not args.sem_janela:
        cv2.waitKey(1500)
        cv2.destroyAllWindows()


if __name__ == "__main__":
    main()
